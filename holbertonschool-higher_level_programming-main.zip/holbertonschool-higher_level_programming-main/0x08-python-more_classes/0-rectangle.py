#!/usr/bin/python3
""" Rectangle

Define an empty class Rectangle
    """


class Rectangle:
    """ Representation of a rectangle """
    pass
