#!/usr/bin/python3
def uniq_add(my_list=[]):

    new_list = set(my_list)
    return sum(new_list)
