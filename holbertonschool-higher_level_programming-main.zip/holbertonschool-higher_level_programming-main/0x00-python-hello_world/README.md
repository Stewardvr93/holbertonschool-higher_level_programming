# 0x00. Python - Hello, World

## Resources

**Read or watch**

- [The Python tutorial (*only the first three chapters below*)](https://docs.python.org/3/tutorial/index.html)
- [Whetting Your Appetite](https://docs.python.org/3/tutorial/appetite.html)
- [Using the Python Interpreter](https://docs.python.org/3/tutorial/interpreter.html)
- [An Informal Introduction to Python (_Read up until “3.1.2. Strings” included_)](https://docs.python.org/3/tutorial/introduction.html)
- [How To Use String Formatters in Python 3](https://www.digitalocean.com/community/tutorials/how-to-use-string-formatters-in-python-3)
- [Learn to Program](https://www.youtube.com/playlist?list=PLGLfVvz_LVvTn3cK5e6LjhgGiSeVlIRwt)
- [Pycodestyle – Style Guide for Python Code](https://pypi.org/project/pycodestyle/)

## Learning Objectives

**General**

- Why Python programming is awesome
- Who created Python
- Who is Guido van Rossum
- Where does the name ‘Python’ come from
- What is the Zen of Python
- How to use the Python interpreter
- How to print text and variables using ``print``
- How to use strings
- What are indexing and slicing in Python
- What is the official Python coding style and how to check your code with ``pycodestyle``

## More Info

**Zen**

> **The Zen of Python**<br>
> By Tim Peters<br>
> <br>
> Beautiful is better than ugly.<br>
> Explicit is better than implicit.<br>
> Simple is better than complex.<br>
> Complex is better than complicated.<br>
> Flat is better than nested.<br>
> Sparse is better than dense.<br>
> Readability counts.<br>
> Special cases aren't special enough to break the rules.<br>
> Although practicality beats purity.<br>
> Errors should never pass silently.<br>
> Unless explicitly silenced.<br>
> In the face of ambiguity, refuse the temptation to guess.<br>
> There should be one-- and preferably only one --obvious way to do it.<br>
> Although that way may not be obvious at first unless you're Dutch.<br>
> Now is better than never.<br>
> Although never is often better than *right* now.<br>
> If the implementation is hard to explain, it's a bad idea.<br>
> If the implementation is easy to explain, it may be a good idea.<br>
> Namespaces are one honking great idea -- let's do more of those!
