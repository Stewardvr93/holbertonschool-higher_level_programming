#!/usr/bin/python3
import sys
sys.stderr.write("and that piece of art is useful - Dora Korpar, 2015-10-19\n")
exit(1)
