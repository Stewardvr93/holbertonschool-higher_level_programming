#!/usr/bin/node
const toPrint = ['C is fun', 'Python is cool', 'JavaScript is amazing'];
let index = 0;
for (index in toPrint) {
  console.log(toPrint[index]);
}
