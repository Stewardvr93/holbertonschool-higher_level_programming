#!/usr/bin/node
console.log('C is fun\nPython is cool\nJavaScript is amazing');
