-- Deletes a database
-- Only if the database exists
DROP DATABASE IF EXISTS hbtn_0c_0;
