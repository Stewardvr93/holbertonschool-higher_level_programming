-- Creates a new database
-- Only if the database does not exits
CREATE DATABASE IF NOT EXISTS hbtn_0c_0;
