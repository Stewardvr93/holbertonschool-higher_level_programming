-- Computes the score average of the 'second_table' (database hbtn_0c_0)
-- * The result column name should be average
SELECT AVG(score) AS average FROM second_table;
