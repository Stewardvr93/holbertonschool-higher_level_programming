-- Lists all the tables of a database
-- The database name will be passed as argument of mysql command
SHOW TABLES;
