-- Inserts a new row in the table first_table
-- From a given database as argument
INSERT INTO first_table (id, name)
VALUES (89, 'Best School');
