-- Prints the full description of the table first_table
-- From a given database as argument
SHOW CREATE TABLE first_table;
