-- Lists all rows (or record) of the table first_table
-- From a given database as argument
SELECT * FROM first_table;
