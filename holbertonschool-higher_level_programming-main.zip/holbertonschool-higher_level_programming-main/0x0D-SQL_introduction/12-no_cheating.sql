-- Updates the score of Bob to 10 in the table second_table (database hbtn_0c_0)
-- * You are not allowed to use Bob’s id value, only the name field
UPDATE second_table
SET score=10 WHERE name='Bob';
