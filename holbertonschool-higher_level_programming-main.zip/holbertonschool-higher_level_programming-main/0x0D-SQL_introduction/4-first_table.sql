-- Creates a new table in a current database 
-- The database name will be passed as an argument of the mysql command
CREATE TABLE IF NOT EXISTS first_table (id INT, name VARCHAR(256));
