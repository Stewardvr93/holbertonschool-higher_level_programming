-- Lists all current databases
-- On the MySQL Server
SHOW DATABASES;
