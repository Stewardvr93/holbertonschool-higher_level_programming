#!/bin/bash
# Script that takes in a URL, sends a POST, and displays the body of the response
curl -sX POST "$1" -d "email=test@gmail.com&subject=I will always be here for PLD"
