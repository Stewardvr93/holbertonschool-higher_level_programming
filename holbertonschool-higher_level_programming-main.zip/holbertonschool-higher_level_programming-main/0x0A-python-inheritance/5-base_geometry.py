#!/usr/bin/python3
""" Geometry module

Contains the class BaseGeometry.
    """


class BaseGeometry():
    """ Empty class of BaseGeometry()  """
    pass
