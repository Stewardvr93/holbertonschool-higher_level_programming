#!/usr/bin/python3
for character in range(97, 123):
    print("{:c}".format(character), end="")
