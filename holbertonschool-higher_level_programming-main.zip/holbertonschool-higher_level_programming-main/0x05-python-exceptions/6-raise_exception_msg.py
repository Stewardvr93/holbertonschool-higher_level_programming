#!/usr/bin/python3
def raise_exception_msg(message=""):
    raise NameError(message)
