#!/usr/bin/python3
def raise_exception():
    try:
        raise
    except raise_exception:
        pass
