#!/usr/bin/python3
""" Set an empty class. """


class Square:
    """ Defines a square. """
    pass
